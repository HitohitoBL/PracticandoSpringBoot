package gt.bchavajay.literalurachallenge.dto;

public record AutorDto(
        Long Id,
        String nombre,
        Integer fechaNacimiento,
        Integer fechaDeceso )
{}
