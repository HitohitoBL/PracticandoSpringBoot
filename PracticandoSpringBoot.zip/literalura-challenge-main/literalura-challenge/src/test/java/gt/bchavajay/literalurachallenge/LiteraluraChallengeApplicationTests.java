package gt.bchavajay.literalurachallenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiteraluraChallengeApplicationTests {

	@Test
	void contextLoads() {
	}

}
